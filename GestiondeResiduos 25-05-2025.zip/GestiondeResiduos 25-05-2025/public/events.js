// window.onload = function() {
//     const successMessageDiv = document.querySelector('.flash-message.success');
//     const errorMessageDiv = document.querySelector('.flash-message.error');
    
//     const genericErrorPassportDiv = document.querySelector('.flash-message.error'); 

//     if (successMessageDiv && successMessageDiv.textContent.trim().length > 0) {
//         alert('Mensaje de Éxito: ' + successMessageDiv.textContent.trim());
//     } else if (errorMessageDiv && errorMessageDiv.textContent.trim().length > 0) {
//         alert('Mensaje de Error: ' + errorMessageDiv.textContent.trim());
//     } else if (genericErrorPassportDiv && genericErrorPassportDiv.textContent.trim().length > 0) {
//         alert('Mensaje de Error General: ' + genericErrorPassportDiv.textContent.trim());
//     }
// };

function togglePasswordVisibility(fieldId, iconElement) {

    const passwordField = document.getElementById(fieldId);
    const toggleIcon = iconElement.querySelector('img');
    

    if (passwordField.type === 'password') {
        passwordField.type = 'text';
        toggleIcon.src = '/images/ojo.png'; // Cambia al icono de ojo abierto
        toggleIcon.alt = 'Ocultar Contraseña';
    } else {
        passwordField.type = 'password';
        toggleIcon.src = '/images/ojoff.png'; // Cambia al icono de ojo cerrado
        toggleIcon.alt = 'Mostrar Contraseña';
    }
}


function onlyNumber(element, maxLength) {
    if (element && element.value !== undefined) {
      // Primero, limpia el valor para dejar solo números
      let cleanValue = element.value.replace(/[^0-9]/g, '');

      // Luego, si se ha especificado un maxLength, trunca el valor
      if (maxLength && cleanValue.length > maxLength) {
        cleanValue = cleanValue.substring(0, maxLength);
      }
      element.value = cleanValue;
    }
  }

function inputName(element) {
    element.value = element.value.replace(/[^A-Z a-z ]/g, '')
}
